This is under development state. Fork it https://github.com/BinPy/BinPy
