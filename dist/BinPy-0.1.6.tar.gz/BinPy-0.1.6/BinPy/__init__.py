from gates import Gates
from binary import Operation
from combi_logic import MUX
from ic import IC_7400, IC_741G00, IC_7401, IC_7402, IC_7403
