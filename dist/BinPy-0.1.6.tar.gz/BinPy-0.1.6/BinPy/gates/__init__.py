from logic_gates import Gates
